import logo from "./logo.svg";
import Routers from "./routes";

function App() {
  return (
    <div className="App">
      <Routers />
    </div>
  );
}

export default App;
